# Outline

<ol>
<li>Introduction (10 minutes)
<a href="CIKM_Introduction.pptx">ppt</a>
<a href="CIKM_Introduction.pdf">pdf</a>
</li>
<li>Hard (10 minutes)
<a href="CIKM_Hard.pptx">ppt</a>
<a href="CIKM_Hard.pdf">pdf</a>
</li>
<li>Easy (60 minutes)
<a href="CIKM_Easy.pptx">ppt</a>
<a href="CIKM_Easy.pdf">pdf</a>
</li>
<li>break</li>
<li>Medium (40 minutes)
<a href="CIKM_Medium.pptx">ppt</a>
<a href="CIKM_Medium.pdf">pdf</a>
</li>
<li>Ugly & Applications (50 minutes)
<a href="CIKM_Ugly.pptx">ppt</a>
<a href="CIKM_Ugly.pdf">pdf</a>
</li>
<li>
Conclusions (10 minutes)
<a href="CIKM_Conclusions.pptx">ppt</a>
<a href="CIKM_Conclusions.pdf">pdf</a>
</li>
</ol>

